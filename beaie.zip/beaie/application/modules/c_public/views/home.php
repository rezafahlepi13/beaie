<!DOCTYPE html>
<html>
  <head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="Ari Rusmanto">
	<title>beaie.id - Responsive Landing Page</title>
	
	<!-- CSS -->
	<link href="<?=base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/animate.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/style.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/css/style-responsive.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/third/font-awesome/css/font-awesome.css');?>" rel="stylesheet">
	<link href="<?=base_url('assets/third/hovericon/css/component.css');?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	  <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->
	</head>
	
	<!-- BODY WITH DATA STYPE FOR SCROLLSPY -->
	<body class="tooltips" id="top" data-spy="scroll" data-target="#myScrollspy">
	
	<!-- START PAGE -->
	<div class="wrapper">
		<div id="header-landing">
			<!-- NAV MENU WRAPPER FOR FIXED POSITION -->
			<div id="nav-menu">
				<!-- NAV MENU CONTAINER -->
				<div class="container-fluid">
					<!-- LOGO -->
					<div id="logo">
						<img class="img-responsive img-logo" src="<?=base_url('assets/img/beaie.svg');?>" onclick="location.href='#" >
					</div><!-- /#logo -->
					<!-- END LOGO -->
					<!-- NAV MENU -->
					<div class="menus" id="myScrollspy">
						<ul class="nav scroll-nav">
							<li class="active"><a href="#top">Home</a></li>
							<li><a href="#about">About</a></li>
							<li><a href="#services">Services</a></li>
							<li><a href="#work">Our Work</a></li>
							<li><a href="#contact">Contact</a></li>
						</ul>
					</div><!-- /.menus -->
				</div><!-- /.container -->
			</div><!-- /.nav-menu -->

			<div class="awesome-slogan">

				<div class="slogan">
					<h2>Hi, We Are <span style="color: #1DB6F0;">Beaie</span><br/>We Craft Your <span style="color: #1DB6F0;">Website</span></h2>
					<button href="contact" class="btn btn-defaults">Contact Us</button>					
				</div>
					<img class="header-img" src="<?=base_url('assets/img/header1.png');?>">
			</div>
		</div><!-- /.header-landing -->

		<!-- SEECTION THEME COLOR -->
		<!-- END SECTION THEME COLOR -->
		<div class="section-page-landing section-light-grey" id="about">
			<div class="inner-section">
				<div class="container">
					<!-- SECTION TITLE -->
					<!-- BEGIN FEATURES DESCRIPTION -->
					<div class="the-box-landing">
						<div class="row">
							<div class="col-lg-12">
							<h1 class="text-center" style="color:#1a8db8;font-weight:bold;">Who We Are</h1>
								<h3 class="text-center" style="font-weight:bold;">We decided to moveforward with building</h3>
								<div>
									<p>As a leading technology consultant and development, Vesperia has been established in 2019. We started as an energetic and dynamic development company. Now, we are leading as technology provider.</p>
									<p>At Beaie, we take innovations not for granted. We know that in every levels, technology is necessary to reach out the goals. In all our works, Vesperia combines innovative insights and aimed goals to answer the technological-needs for our partners.</p>
								</div>
							</div><!-- /.col-sm-9 -->
						</div><!-- /.row -->
					</div><!-- /.the-box-landing .border-color-left -->
					<!-- END CALL TO ACTION -->
				</div><!-- /.container -->
			</div><!-- /.inner-section -->
		</div><!-- /.section-page-landing .section-light-grey -->
		<div class="section-page-landing section-grey" id="services">
				<div class="inner-section">
					<div class="container">
						<!-- BEGIN HEADING SECTION -->
						<h1 class="text-center" style="color:#fff;font-weight:bold;">Our Services</h1>
						<!-- END HEADING SECTION -->
						<!-- BEGIN SERVICES DESCRIPTION -->
						
						<div class="hi-icon-effect-1 hi-icon-effect-1a">
							<div class="row">
								<div class="col-sm-4">
									<div class="the-box-landing the-box-transparent text-center">
										<h4 style="font-weight:bold;color:#fff;">IT CONSULTANT</h4>
										<a href="#fakelink"><img class="hi-icon" src="<?=base_url();?>/assets/img/icon/consultant.png" alt="SEO"></a>
										<div class="testimonial-inner">
											<h4  >
											provide appropriate solutions, security and ease of implementation
											</h4>
										</div><!-- /.testimonial-inner -->

									</div><!-- /.the-box-landing .the-box-transparent .text-center -->
								</div><!-- /.col-sm-3 -->
								<div class="col-sm-4">
									<div class="the-box-landing the-box-transparent text-center">
										<h4 style="font-weight:bold;color:#fff;">WEB APPS</h4>
										<a href="#fakelink"><img class="hi-icon" src="<?=base_url();?>/assets/img/icon/web.png" alt="SEO"></a>
										<div class="testimonial-inner">
											<h4>
											develop a website-based application for you to be able to access anywhere at any time in a variety of gadgets
											</h4>
										</div><!-- /.testimonial-inner -->
									</div><!-- /.the-box-landing .the-box-transparent .text-center -->
								</div><!-- /.col-sm-3 -->
								<div class="col-sm-4">
									<div class="the-box-landing the-box-transparent text-center">
										<h4 style="font-weight:bold;color:#fff;">MOBILE APPS</h4>
										<a href="#fakelink"><img class="hi-icon" src="<?=base_url();?>/assets/img/icon/mobile.png" alt="SEO"></a>
										<div class="testimonial-inner">
											<h4>
											grow your business and make it easy for your customers to reach your business products into mobile applications
											</h4>
										</div><!-- /.testimonial-inner -->
									</div><!-- /.the-box-landing .the-box-transparent .text-center -->
								</div><!-- /.col-sm-3 -->
							</div><!-- /.row -->
							<div class="row">
								<div class="col-sm-4">
									<div class="the-box-landing the-box-transparent text-center">
										<h4 style="font-weight:bold;color:#fff;">SEO</h4>
										<a href="#fakelink"><img class="hi-icon" src="<?=base_url();?>/assets/img/icon/seo.png" alt="SEO"></a>
										<div class="testimonial-inner">
											<h4>
											provide services that are well targeted, so your customers can easily find your products
											</h4>
										</div><!-- /.testimonial-inner -->
									</div><!-- /.the-box-landing .the-box-transparent .text-center -->
								</div><!-- /.col-sm-3 -->
								<div class="col-sm-4">
									<div class="the-box-landing the-box-transparent text-center">
										<h4 style="font-weight:bold;color:#fff;">IT INFRASTRUCTURE</h4>
										<a href="#fakelink"><img class="hi-icon" src="<?=base_url();?>/assets/img/icon/infrastructure.png" alt="SEO"></a>
										<div class="testimonial-inner">
											<h4>
											provide appropriate and efficient infrastructure in various systems
											</h4>
										</div><!-- /.testimonial-inner -->
									</div><!-- /.the-box-landing .the-box-transparent .text-center -->
								</div><!-- /.col-sm-3 -->
								<div class="col-sm-4">
									<div class="the-box-landing the-box-transparent text-center">
										<h4 style="font-weight:bold;color:#fff;">WEB HOSTING</h4>
										<a href="#fakelink"><img class="hi-icon" src="<?=base_url();?>/assets/img/icon/hosting.png" alt="SEO"></a>
										<div class="testimonial-inner">
											<h4>
											make your business products accessible anywhere 24/7 without you having to take care of it all the time
											</h4>
										</div><!-- /.testimonial-inner -->
									</div><!-- /.the-box-landing .the-box-transparent .text-center -->
								</div><!-- /.col-sm-3 -->
							</div><!-- /.row --><!-- /.row -->
						</div><!-- /.hi-icon-effect-1 .hi-icon-effect-1a -->
					</div><!-- /.container -->
				</div><!-- /.inner-section -->
		</div><!-- /.section-page-landing .section-grey -->
		<!-- 
		===========================================
		END SERVICES SECTION
		===========================================
		-->
		
		
		
		
		<!-- 
		===========================================
		BEGIN PORTFOLIO SECTION
		===========================================
		-->
		<div class="section-page-landing" id="work">
			<div class="inner-section">
				<!-- BEGIN MODAL PORTFOLIO -->
				<div class="modal fade" id="javandra" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
						<!-- MODAL HEADER -->
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title" id="myModalLabel">Javandara</h4>
						</div>
						<!-- MODAL BODY -->
						<div class="modal-body">
						<img src="<?=base_url();?>/assets/images/blog-img/image001.jpg" class="img-responsive" alt="Image portfolio">
						<hr />
							<div class="row">
								<div class="col-sm-4">
									<button class="btn btn-default btn-teplok btn-block">Launch project</button>
									<table class="table table-modal-project">
										<tbody>
											<tr><td><strong>Type</strong></td><td class="text-right">Photography</td></tr>
											<tr><td><strong>Client</strong></td><td class="text-right">Marlboro</td></tr>
											<tr><td><strong>Year</strong></td><td class="text-right">2014</td></tr>
										</tbody>
									</table>
								</div><!-- /.col-sm-4 -->
								<div class="col-sm-8">
									<p style="text-align: justify">
									Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
									</p>
								</div><!-- /.col-sm-8 -->
							</div><!-- /.row -->
						</div><!-- /.modal-body -->
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /.modal .fade -->
				<!-- END MODAL PORTFOLIO -->
				<div class="modal fade" id="sayuransiapsaji" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
						<!-- MODAL HEADER -->
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title" id="myModalLabel">Sayuran Siap Saji </h4>
						</div>
						<!-- MODAL BODY -->
						<div class="modal-body">
						<img src="<?=base_url();?>/assets/images/blog-img/image001.jpg" class="img-responsive" alt="Image portfolio">
						<hr />
							<div class="row">
								<div class="col-sm-4">
									<button class="btn btn-default btn-teplok btn-block">Launch project</button>
									<table class="table table-modal-project">
										<tbody>
											<tr><td><strong>Type</strong></td><td class="text-right">Photography</td></tr>
											<tr><td><strong>Client</strong></td><td class="text-right">Marlboro</td></tr>
											<tr><td><strong>Year</strong></td><td class="text-right">2014</td></tr>
										</tbody>
									</table>
								</div><!-- /.col-sm-4 -->
								<div class="col-sm-8">
									<p style="text-align: justify">
									Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
									</p>
								</div><!-- /.col-sm-8 -->
							</div><!-- /.row -->
						</div><!-- /.modal-body -->
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /.modal .fade -->
				<div class="modal fade" id="saungmirwan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
						<!-- MODAL HEADER -->
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title" id="myModalLabel">Saung Mirwan </h4>
						</div>
						<!-- MODAL BODY -->
						<div class="modal-body">
						<img src="<?=base_url();?>/assets/images/blog-img/image001.jpg" class="img-responsive" alt="Image portfolio">
						<hr />
							<div class="row">
								<div class="col-sm-4">
									<button class="btn btn-default btn-teplok btn-block">Launch project</button>
									<table class="table table-modal-project">
										<tbody>
											<tr><td><strong>Type</strong></td><td class="text-right">Photography</td></tr>
											<tr><td><strong>Client</strong></td><td class="text-right">Marlboro</td></tr>
											<tr><td><strong>Year</strong></td><td class="text-right">2014</td></tr>
										</tbody>
									</table>
								</div><!-- /.col-sm-4 -->
								<div class="col-sm-8">
									<p style="text-align: justify">
									Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
									</p>
								</div><!-- /.col-sm-8 -->
							</div><!-- /.row -->
						</div><!-- /.modal-body -->
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /.modal .fade -->
				<div class="modal fade" id="rajafriedchicken" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
						<!-- MODAL HEADER -->
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title" id="myModalLabel">Raja Fried Chicken </h4>
						</div>
						<!-- MODAL BODY -->
						<div class="modal-body">
						<img src="<?=base_url();?>/assets/images/blog-img/image001.jpg" class="img-responsive" alt="Image portfolio">
						<hr />
							<div class="row">
								<div class="col-sm-4">
									<button class="btn btn-default btn-teplok btn-block">Launch project</button>
									<table class="table table-modal-project">
										<tbody>
											<tr><td><strong>Type</strong></td><td class="text-right">Photography</td></tr>
											<tr><td><strong>Client</strong></td><td class="text-right">Marlboro</td></tr>
											<tr><td><strong>Year</strong></td><td class="text-right">2014</td></tr>
										</tbody>
									</table>
								</div><!-- /.col-sm-4 -->
								<div class="col-sm-8">
									<p style="text-align: justify">
									Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
									</p>
								</div><!-- /.col-sm-8 -->
							</div><!-- /.row -->
						</div><!-- /.modal-body -->
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /.modal .fade -->
				<div class="modal fade" id="sktpdsi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
						<!-- MODAL HEADER -->
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title" id="myModalLabel">SKTPDSI </h4>
						</div>
						<!-- MODAL BODY -->
						<div class="modal-body">
						<img src="<?=base_url();?>/assets/images/blog-img/image001.jpg" class="img-responsive" alt="Image portfolio">
						<hr />
							<div class="row">
								<div class="col-sm-4">
									<button class="btn btn-default btn-teplok btn-block">Launch project</button>
									<table class="table table-modal-project">
										<tbody>
											<tr><td><strong>Type</strong></td><td class="text-right">Photography</td></tr>
											<tr><td><strong>Client</strong></td><td class="text-right">Marlboro</td></tr>
											<tr><td><strong>Year</strong></td><td class="text-right">2014</td></tr>
										</tbody>
									</table>
								</div><!-- /.col-sm-4 -->
								<div class="col-sm-8">
									<p style="text-align: justify">
									Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
									</p>
								</div><!-- /.col-sm-8 -->
							</div><!-- /.row -->
						</div><!-- /.modal-body -->
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /.modal .fade -->
				<div class="modal fade" id="arlindo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
						<!-- MODAL HEADER -->
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title" id="myModalLabel">arlindo</h4>
						</div>
						<!-- MODAL BODY -->
						<div class="modal-body">
						<img src="<?=base_url();?>/assets/images/blog-img/image001.jpg" class="img-responsive" alt="Image portfolio">
						<hr />
							<div class="row">
								<div class="col-sm-4">
									<button class="btn btn-default btn-teplok btn-block">Launch project</button>
									<table class="table table-modal-project">
										<tbody>
											<tr><td><strong>Type</strong></td><td class="text-right">Photography</td></tr>
											<tr><td><strong>Client</strong></td><td class="text-right">Marlboro</td></tr>
											<tr><td><strong>Year</strong></td><td class="text-right">2014</td></tr>
										</tbody>
									</table>
								</div><!-- /.col-sm-4 -->
								<div class="col-sm-8">
									<p style="text-align: justify">
									Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
									</p>
								</div><!-- /.col-sm-8 -->
							</div><!-- /.row -->
						</div><!-- /.modal-body -->
					</div><!-- /.modal-content -->
				  </div><!-- /.modal-dialog -->
				</div><!-- /.modal .fade -->
				<div class="container">
					<h1 class="text-center" style="color:#1DB6F0;font-weight:bold;">Our Work</h1>
					<div class="portfolio-landing">
						<!-- PORTFOLIO CATEGORY FILTER -->
						<ul class="nav nav-pills nav-justified">
							<li class="filter" data-filter="web_apps">Web Apps</li>
							<li class="filter" data-filter="ui_design">UI Design</li>
							<li class="filter" data-filter="logo_design">Logo Design</li>
							<li class="filter" data-filter="photography">Photography</li>
						</ul>
						<!-- END PORTFOLIO CATEGORY FILTER -->
						<!-- BEGIN PORTFOLIO GRID CONTENT -->
						<ul id="portfolio-grid">
						<li class="mix web_apps">
								<div class="des">
									<h4>Javandra</h4>
									<h5>ICT Service Infrastructure</h5>
									<p>
										<a data-toggle="modal" data-target="#javandra"><i class="fa fa-share"></i></a>
										<a href="https://www.javandra.com/"><i class="fa fa-link"></i></a>
									</p>
								</div>
								<img src="<?=base_url();?>/assets/images/image_small/javandra.jpg" alt="Image portfolio">
							</li>
							<li class="mix web_apps">
								<div class="des">
									<h4>Sayuran Siap Saji</h4>
									<h5>vegetable supply company</h5>
									<p>
										<a data-toggle="modal" data-target="#sayuransiapsaji"><i class="fa fa-share"></i></a>
										<a href="https://sayuransiapsaji.co.id"><i class="fa fa-link"></i></a>
									</p>
								</div>
								<img src="<?=base_url();?>/assets/images/image_small/sayur_siap_saji.jpg" alt="Image portfolio">
							</li>
							<li class="mix web_apps">
								<div class="des">
									<h4>Saung Mirwan</h4>
									<h5>vegetable supply company</h5>
									<p>
										<a data-toggle="modal" data-target="#saungmirwan"><i class="fa fa-share"></i></a>
										<a href="http://saungmirwan.co.id"><i class="fa fa-link"></i></a>
									</p>
								</div>
								<img src="<?=base_url();?>/assets/images/image_small/saung_mirwan.jpg" alt="Image portfolio">
							</li>
							<li class="mix web_apps">
								<div class="des">
									<h4>Raja Fried Chicken</h4>
									<h5>fast food company</h5>
									<p>
										<a data-toggle="modal" data-target="#rajafriedchicken"><i class="fa fa-share"></i></a>
										<a href="https://rajafriedchicken.id/"><i class="fa fa-link"></i></a>
									</p>
								</div>
								<img src="<?=base_url();?>/assets/images/image_small/raja_fried_chicken.jpg" alt="Image portfolio">
							</li>
							<li class="mix web_apps">
								<div class="des">
									<h4>SKTPDSI</h4>
									<h5>Pertamina's drilling partners</h5>
									<p>
										<a data-toggle="modal" data-target="#sktpdsi"><i class="fa fa-share"></i></a>
										<a href="https://www.sktpdsi.co.id/home"><i class="fa fa-link"></i></a>
									</p>
								</div>
								<img src="<?=base_url();?>/assets/images/image_small/skt_pdsi.jpg" alt="Image portfolio">
							</li>
							<li class="mix web_apps">
								<div class="des">
									<h4>ARLINDO</h4>
									<h5>holding company for several types of businesses</h5>
									<p>
										<a data-toggle="modal" data-target="#arlindo"><i class="fa fa-share"></i></a>
										<a href="https://arlindo.id/"><i class="fa fa-link"></i></a>
									</p>
								</div>
								<img src="<?=base_url();?>/assets/images/image_small/arlindo.jpg" alt="Image portfolio">
							</li>
						</ul>
						<!-- END PORTFOLIO GRID CONTENT -->
					</div><!-- /.portfolio-landing -->
				</div><!-- /.container -->
			</div><!-- /.inner-section -->
		</div><!-- /.section-page-landing -->
		<div class="section-page-landing" id="contact">
			<div class="inner-section">
				<div class="container">
					<h2 class="text-center">Get in Touch</h2>
					<div class="col-sm-6">
						<form role="form" class="contact-form" id="ContactForm" method="post">
							<div class="row">
								<div class="col-sm-6">
								  <div class="form-group">
									<input type="text" name="YourName" class="form-control" placeholder="Your name">
								  </div>
								</div>
								<div class="col-sm-6">
								  <div class="form-group">
									<input type="email" name="YourEmail" class="form-control" placeholder="Your email">
								  </div>
								</div>
							</div>
						  <div class="form-group">
							<textarea class="form-control" name="YourMessage" style="height: 200px" placeholder="Your message"></textarea>
						  </div>
							<div class="row">
								<div class="col-sm-7">
								  <div class="col-sm-5">
									<h4 id="SimpleCaptcha"></h4>
								  </div>
								  <div class="col-sm-7">
									<input type="text" name="captcha" class="form-control" placeholder="Result">
								  </div>
								</div>
								<div class="col-sm-5">
								</div>
							</div>
							<button type="submit" class="btn btn-default btn-teplok"><i class="fa fa-envelope"></i>Submit</button>
						</form>
					</div>
					<div class="col-sm-6">
						Contact<br/>
						Wasap
					</div>
				</div><!-- /.container -->
			</div><!-- /.inner-section -->
		</div><!-- /.section-page-landing -->
		<!-- 
		===========================================
		END CONTACT SECTION
		===========================================
		-->