CKEDITOR.plugins.setLang('jsplus_image_editor', 'en', {
    jsplus_image_editor_title: "Edit image",

    btn_ok: "OK",
    btn_cancel: "Cancel"
} );