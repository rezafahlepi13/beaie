CKEDITOR.plugins.setLang('jsplus_image_editor', 'ru', {
        jsplus_image_editor_title: "Редактировать",

        btn_ok: "OK",
        btn_cancel: "Отмена"
	}
);