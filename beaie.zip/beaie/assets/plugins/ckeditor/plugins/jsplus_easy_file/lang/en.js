CKEDITOR.plugins.setLang('jsplus_easy_file', 'en',	{
        jsplus_easy_image_button_label: "Easy insert image",
        jsplus_easy_preview_button_label: "Easy insert image preview",
        jsplus_easy_file_button_label: "Easy insert file"
});
