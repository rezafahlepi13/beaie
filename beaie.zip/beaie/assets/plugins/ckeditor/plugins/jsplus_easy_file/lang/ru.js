CKEDITOR.plugins.setLang('jsplus_easy_file', 'ru',	{
        jsplus_easy_image_button_label: "Простая загрузка изображения",
        jsplus_easy_preview_button_label: "Простая загрузка изображения с превью",
        jsplus_easy_file_button_label: "Простая вставка файла"
});
