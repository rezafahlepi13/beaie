CKEDITOR.plugins.setLang(
	
	
	
		'jsplus_rehost_file',
	
	
	'en',
	{	
		
		
			jsplus_rehost_file:
		
		{
				
				
				
					button_label: "Rehost and insert file",
					ui_multiline_comment: "Insert URLs to files here, one link per line:",
					ui_singleline_comment: "URL of file:",
				
				
				
				
					dlg_title: "Rehost and insert file",
				
				
				
					download_label: "Download file",
				
				
				rehost_error: "Unable to rehost URL:",
				uploader_error: "Error response from server uploader",
				empty_urls: "Specify URL addresses",
				empty_url: "Specify URL address"
		}
	}
);
