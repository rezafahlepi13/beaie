CKEDITOR.plugins.setLang(
	
	
	
		'jsplus_rehost_file',
	
	
	'ru',
	{	
		
		
			jsplus_rehost_file:
		
		{
				
				
				
					button_label: "Скачивание на сервер и вставка файла",
					ui_multiline_comment: "Вставьте URL'ы загружаемых файлов в это поле, по одной ссылке на строку:",
					ui_singleline_comment: "URL файла:",
				
				
				
				
					dlg_title: "Скачивание на сервер и вставка файла",
				
				
				
					download_label: "Скачать файл",
				
				
				rehost_error: "Невозможно загрузить URL:",
				uploader_error: "Получена ошибка от серверного загрузчика",
				empty_urls: "Укажите URL-адреса",
				empty_urls: "Укажите URL-адрес"
		}
	}
);
