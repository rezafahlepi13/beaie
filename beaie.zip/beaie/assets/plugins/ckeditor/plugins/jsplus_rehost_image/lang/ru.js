CKEDITOR.plugins.setLang(
	
	
		'jsplus_rehost_image',
	
	
	
	'ru',
	{	
		
			jsplus_rehost_image:
		
		
		{
				
					button_label: "Скачивание на сервер и вставка изображения",
					ui_multiline_comment: "Вставьте URL'ы загружаемых картинок в это поле, по одной ссылке на строку:",
					ui_singleline_comment: "URL изображения:",
				
				
					resize: "Макс. размер",
					resize_up: "Масштабировать в сторону увеличения",
				
				
				
				
					dlg_title: "Скачивание на сервер и вставка изображения",
				
				
				
				
				
				rehost_error: "Невозможно загрузить URL:",
				uploader_error: "Получена ошибка от серверного загрузчика",
				empty_urls: "Укажите URL-адреса",
				empty_urls: "Укажите URL-адрес"
		}
	}
);
