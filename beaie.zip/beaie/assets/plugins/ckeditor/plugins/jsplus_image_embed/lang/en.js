CKEDITOR.plugins.setLang('jsplus_image_embed', 'en',	{
        button_label: "Embed image",
        no_support: "Your browser does not support required HTML5 features"
});
