CKEDITOR.plugins.setLang('jsplus_image_embed', 'ru',	{
    button_label: "Встроить изображение",
    no_support: "Ваш броузер не поддерживает необходимый HTML5 функционал"
});
